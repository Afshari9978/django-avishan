from django.apps import AppConfig


class AvishanConfig(AppConfig):
    name = 'avishan'
