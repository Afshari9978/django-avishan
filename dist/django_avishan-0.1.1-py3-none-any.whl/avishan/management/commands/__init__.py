# todo implement commands
# todo have a command to list available commands
